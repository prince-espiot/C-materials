#include <iostream>
#include "vector_it.hpp"

int main(void) {
    auto v = ReadVector();
    PrintSum1(v);
    PrintSum2(v);
    return 0;
}
