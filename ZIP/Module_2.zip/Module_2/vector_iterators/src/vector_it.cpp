#include <iostream>
#include <vector>
#include "vector_it.hpp"

// Implement the functions here


