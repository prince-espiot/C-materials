#include "list.hpp"
#include <iostream>

// Implement the functions here

