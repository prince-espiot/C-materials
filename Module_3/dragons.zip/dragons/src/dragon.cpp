#include "dragon.hpp"


Dragon::Dragon(const std::string& name, size_t age, size_t size):name_(name),age_(age),size_(size)
{

}

const std::string& Dragon::GetName() const {
    return name_;
}

size_t  Dragon::GetAge() const{
    return age_;
}

size_t Dragon::GetSize() const{
    return size_;
}


const std::list<Treasure>& Dragon::GetTreasures() const{
    return treasures;
}

std::ostream& operator<<(std::ostream& out, const Dragon& drag){
    out << "Dragon named: " << drag.GetName() << ", age: " << drag.GetAge() <<", size: "<< drag.GetSize() <<std::endl;
    out<<"Treasure:"<<std::endl;

    for (auto i : drag.GetTreasures())
    {
        out<<i.name<<std::endl;
        
    }
    return out;
} 

