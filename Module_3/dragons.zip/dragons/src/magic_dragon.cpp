#include "magic_dragon.hpp"

//MagicDragon::MagicDragon (const std::string& name, size_t age, size_t size):Dragon( name,  age,  size){}

void MagicDragon::Eat(std::list<Food>& food)  {

    auto it = food.begin();

    while (it != food.end()) {

        if (it->type == FoodType::Herbs)

        {

            this->size_ += 1;

            std::cout << "Magic dragon ate: " << it->name << std::endl;

            food.erase(it);

            it = food.begin();

        } else {it++;}

    }

}


void Hoard(std::list<Treasure>&treasure)  {
    auto it = treasure.begin();

    std::list <Treasure> tee;

    while (it != treasure.end())
    {
        if (it->type == TreasureType::Potions){ 
            tee.push_back(*it);     
            std::cout<<"Magic dragon received:"<<it->name<<std::endl;
            treasure.erase(it);
            
        }else{it++;}
    }
    

}