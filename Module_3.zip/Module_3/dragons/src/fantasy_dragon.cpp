#include "fantasy_dragon.hpp"

// Define FantasyDragon's methods here
