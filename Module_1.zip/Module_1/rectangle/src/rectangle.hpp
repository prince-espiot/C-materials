#ifndef AALTO_ELEC_CPP_RECTANGLE
#define AALTO_ELEC_CPP_RECTANGLE

void Rectangle();

#endif
