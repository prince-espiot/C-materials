#include <iostream>

#include "rectangle.hpp"

int main(void) {
    Rectangle();

    return 0;
}
