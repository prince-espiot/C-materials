#ifndef AALTO_ELEC_CPP_FIRST
#define AALTO_ELEC_CPP_FIRST

void Hello();

#endif
