#include "poly.hpp"
#include <sstream>
#include <vector>
#include<iostream>


Poly& Poly::operator+=(Poly const& b) {

    for (auto const& i: b.values_) {
        values_[i.first] += i.second;
    }
    return *this;
}

Poly operator+(const Poly& a, const Poly& b){
    Poly add;
    add += a;
    add += b;
    return add;
}

Poly& Poly::operator-=(Poly const& b) {
    for (auto const& i: b.values_) {
        values_[i.first] -= i.second;
    }
    return *this;
}
Poly operator-(const Poly& a, const Poly& b) {
    Poly sub;
    sub += a;
    sub -= b;
    return sub;
}
Poly operator-(const Poly& p) {
    Poly sub;
    sub -= p;
    return sub;
    }

std::istream& operator>>(std::istream& is, Poly& p) {
    
    //just pass it to a string
   // std::vector<std::string> vec; 
    for (auto iter = p.cbegin(); iter != p.cend(); ++iter )
    {
        
        std::string a,b;
        a =  iter->first;
        b =  iter->second;
        std::getline(is, a, '+');  
        std::getline(is, b, 'x');
        is >> p[std::stoi(b)];
        std::cout<<"FIND A"<<a<<std::endl;
        //means theere is nothin my b and ideas yes, but i dont know how
    }
     
    return is; 

}

std::ostream& operator<<(std::ostream& os, const Poly& p){
      auto it = p.rbegin();
   auto end = p.rend();
   while (it != end) {
      os << it->second << "x" << it->first;
      it++;
      if (it != end) {
         if (it->second >= 0)
            os << "+";
      }
   }
   return os;
}  //same thing diferent implmentation
    /* for (auto iter = p.rbegin(); iter != p.rend(); ++iter){  
        if ( iter != p.rbegin()) {
            if  (iter->second > 0){
            os << "+" << iter->second << 'x' << iter->first;}
        else {
            os << iter->second << 'x' << iter->first;
            }
        }
        else{
                {os << iter->second <<'x' << iter->first;}
            }
    }
    return os;}  */
   /* for (auto iter = p.rbegin(); iter != p.rend(); ++iter)
    {   auto a = --p.rend();
        if (iter != a)
        {os << iter->second <<'x' << iter->first <<"+";}
        else {os << iter->second <<'x' << iter->first;}
}  
    return os;} */

bool operator<(const Poly& a, const Poly& b) {
    if (a.end()->first != 0 && b.end()->first != 0){
        return a.end()->first < b.end()->first;
        }

    else if (a.end()->first == 0 && b.end()->first != 0) {
        return true;
    }

    else if (a.end()->first  > b.end()->first ) {
            return false;
    }

    else if (a.end()->first != 0 && b.end()->first == 0) {
        return false;
    }
    else { return false;}
    }

bool operator>(const Poly& a, const Poly& b){
    if (a.end()->first != 0 && b.end()->first != 0){
        return a.end()->first > b.end()->first;
        }
    else if (a.end()->first == 0 && b.end()->first != 0) {
        return false;
    }
    else if (a.end()->first != 0 && b.end()->first == 0) {
        return true;
    }
    else { return false;}
    }

bool operator==(const Poly& a, const Poly& b) {
        return a.end()->first == b.end()->first;
    }

bool operator!=(const Poly& a, const Poly& b) {
        return a.end()->first != b.end()->first;
}